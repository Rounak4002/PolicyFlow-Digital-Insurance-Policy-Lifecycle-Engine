
# PolicyFlow – Digital Insurance Policy Lifecycle Engine

## Description
PolicyFlow is a backend-driven insurance policy management system designed to handle policy creation, premium handling, and lifecycle tracking.

## Features
- Policy onboarding
- Premium management
- Policy lifecycle tracking
- REST API backend

## Tech Stack
- Backend: Python (FastAPI)
- Frontend: HTML + JavaScript
- Database: SQLite

## How to Run
1. Install dependencies:
   pip install -r backend/requirements.txt
2. Start server:
   uvicorn backend.app.main:app --reload
3. Open frontend/index.html in browser
